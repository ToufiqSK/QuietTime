package com.example.quiettimeapp.GeneralLocations;

import android.app.PendingIntent;

public class GLocationPendingIntentHolder {
    public static PendingIntent pendingIntent = null;
}


